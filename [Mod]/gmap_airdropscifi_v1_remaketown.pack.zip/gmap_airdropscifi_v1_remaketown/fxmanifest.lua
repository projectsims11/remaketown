fx_version 'adamant'
game 'gta5'
this_is_a_map 'yes'

files {

	"stream/*.ytd",
	"stream/*.ydr",
	"stream/*.ycd",
}

data_file 'DLC_ITYP_REQUEST' 'stream/lb_cave_01.ytyp'

dependency '/assetpacks'