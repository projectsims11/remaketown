fx_version 'adamant'
game 'gta5'
this_is_a_map 'yes'