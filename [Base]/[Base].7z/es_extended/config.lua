Config = {}
Config.Locale = GetConvar('esx:locale', 'en')

Config.Accounts = {
	bank = {
		label = TranslateCap('account_bank'),
		round = true
	},
	black_money = {
		label = TranslateCap('account_black_money'),
		round = true
	},
	money = {
		label = TranslateCap('account_money'),
		round = true
	}
}

Config["Base"] = {
	['SetGameType']	= 'HFUNDEV Powered By Fewthz' ,
	['SetMapName']	= 'Discord : https://discord.gg/7Hn4WCf' ,
	['Font'] = 'sarabun' ,
	['ViewServerCallbacks'] =  true ,	-- ไว้สำหรับดู Callbacks หน้า CMD
	['NCinventory'] = false ,	-- ใช้กระเป๋า Nc Developer ให้ปรับเป็น true / ใช้กระเป๋า Fewthz_inventory และอื่นๆ ให้ปรับเป็น false
}

Config["updateCoords"] = {
	['Time'] = 10 , 	-- หน่วยเป็นวิ
}

Config['Position'] = {
	{ x = -257.261536, y = -980.571411, z = 31.217529, heading = 28.346457};
}

Config.StartingAccountMoney 	= {
	money = 10000, 
	bank = 0, 
	black_money = 0
}

Config.EnablePaycheck			= true -- เปิดใช้งานเช็คเงินเดือน
Config.EnableSocietyPayouts 	= false -- จ่ายจากบัญชีโซเชียลที่ผู้เล่นทำงานอยู่? ข้อกำหนด: esx_society
Config.PaycheckInterval         = 7 * 60000 -- ความถี่ในการรับเช็คจ่ายเป็น - มิลลิวินาที
Config.EnableDebug              = false -- ใช้ตัวเลือกการแก้ไขข้อบกพร่องหรือไม่
Config.EnableWantedLevel    	= false -- ใช้ระดับ GTA ปกติที่ต้องการหรือไม่
Config.EnablePVP                = true  -- อนุญาตให้ผู้เล่นต่อสู้ผู้เล่น

Config.DistanceGive 			= 4.0 -- ระยะทางสูงสุดเมื่อมอบสิ่งของ อาวุธ ฯลฯ

Config.DisableHealthRegeneration  = false -- ผู้เล่นจะไม่ฟื้นฟูพลังชีวิตอีกต่อไป
Config.DisableVehicleRewards      = false -- ปิดใช้งานการรับอาวุธของผู้เล่นจากยานพาหนะ
Config.DisableNPCDrops            = false -- หยุด NPC จากการวางอาวุธเมื่อตาย
Config.DisableWeaponWheel         = false -- ปิดการใช้งานวงล้ออาวุธเริ่มต้น
Config.DisableAimAssist           = false -- ปิดใช้งาน AIM Assist (ส่วนใหญ่บนคอนโทรลเลอร์)
Config.RemoveHudCommonents = {
	[1] = false, --WANTED_STARS,
	[2] = false, --WEAPON_ICON
	[3] = false, --CASH
	[4] = false,  --MP_CASH
	[5] = false, --MP_MESSAGE
	[6] = false, --VEHICLE_NAME
	[7] = false,-- AREA_NAME
	[8] = false,-- VEHICLE_CLASS
	[9] = false, --STREET_NAME
	[10] = false, --HELP_TEXT
	[11] = false, --FLOATING_HELP_TEXT_1
	[12] = false, --FLOATING_HELP_TEXT_2
	[13] = false, --CASH_CHANGE
	[14] = false, --RETICLE
	[15] = false, --SUBTITLE_TEXT
	[16] = false, --RADIO_STATIONS
	[17] = false, --SAVING_GAME,
	[18] = false, --GAME_STREAM
	[19] = false, --WEAPON_WHEEL
	[20] = false, --WEAPON_WHEEL_STATS
	[21] = false, --HUD_COMPONENTS
	[22] = false, --HUD_WEAPONS
}

Config['SpawnVehMaxUpgrades'] = true -- เสกรถแล้วแต่งเต็ม
Config['NumberPlateText'] 		= "HFUN DEV" -- ป้ายทะเบียน
Config['CustomAIPlates'] = 'HFUN.AI11' -- ป้ายทะเบียนสำหรับรถ AI
-- รูปแบบสตริงรูปแบบ
--1 จะนำไปสู่ตัวเลขสุ่มตั้งแต่ 0-9
--A จะนำไปสู่ตัวอักษรแบบสุ่มจาก A-Z
-- . จะนำไปสู่การสุ่มตัวอักษรหรือตัวเลข โดยมีโอกาส 50% ที่จะเป็นอย่างใดอย่างหนึ่ง
--^1 จะนำไปสู่การปล่อย 1 ตามตัวอักษร
--^A จะนำไปสู่การเปล่ง A ตามตัวอักษร
--อักขระอื่นใดจะนำไปสู่การเปล่งอักขระดังกล่าว
-- สตริงที่สั้นกว่า 8 อักขระจะถูกเติมทางด้านขวา