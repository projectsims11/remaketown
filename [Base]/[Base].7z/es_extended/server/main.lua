SetMapName(Config["Base"]['SetMapName'])
SetGameType(Config["Base"]['SetGameType'])

local newPlayer = 'INSERT INTO `users` SET `accounts` = ?, `identifier` = ?, `group` = ?'
local loadPlayer = 'SELECT `accounts`, `job`, `job_grade`, `group`, `position`, `inventory`, `skin`, `loadout`, `phone_number`'
loadPlayer = loadPlayer .. ' FROM `users` WHERE identifier = ?'


  RegisterNetEvent('esx:onPlayerJoined')
  AddEventHandler('esx:onPlayerJoined', function()
    local _source = source
    while not next(ESX.Jobs) do
      Wait(50)
    end

    if not ESX.Players[_source] then
      onPlayerJoined(_source)
    end
  end)

function onPlayerJoined(playerId)
  local identifier

	for k,v in ipairs(GetPlayerIdentifiers(playerId)) do
		if string.match(v, 'steam:') then
			identifier = string.sub(v, 0)
			break
		end
	end
  
  if identifier then
    if ESX.GetPlayerFromIdentifier(identifier) then
      DropPlayer(playerId,
        ('there was an error loading your character!\nError code: identifier-active-ingame\n\nThis error is caused by a player on this server who has the same identifier as you have. Make sure you are not playing on the same Rockstar account.\n\nYour Rockstar identifier: %s'):format(
          identifier))
    else
      local result = MySQL.scalar.await('SELECT 1 FROM users WHERE identifier = ?', {identifier})
      if result then
        loadESXPlayer(identifier, playerId, false)
      else
        createESXPlayer(identifier, playerId)
      end
    end
  else
    DropPlayer(playerId,
      'there was an error loading your character!\nError code: identifier-missing-ingame\n\nThe cause of this error is not known, your identifier could not be found. Please come back later or report this problem to the server administration team.')
  end
end

function createESXPlayer(identifier, playerId, data)
  local accounts = {}

  for account, money in pairs(Config.StartingAccountMoney) do
    accounts[account] = money
  end

  local defaultGroup = "user"
  if Core.IsPlayerAdmin(playerId) then
    print(('[^2INFO^0] Player ^5%s^0 Has been granted admin permissions via ^5Ace Perms^7.'):format(playerId))
    defaultGroup = "admin"
  end


    MySQL.prepare(newPlayer,
      {json.encode(accounts), identifier, defaultGroup}, function()
        loadESXPlayer(identifier, playerId, true)
    end)
end

AddEventHandler('playerConnecting', function(name, setCallback, deferrals)
  deferrals.defer()
  local playerId = source
  local identifier = ESX.GetIdentifier(playerId)

  if identifier then
    if ESX.GetPlayerFromIdentifier(identifier) then
      deferrals.done(
        ('[ESX] There was an error loading your character!\nError code: identifier-active\n\nThis error is caused by a player on this server who has the same identifier as you have. Make sure you are not playing on the same account.\n\nYour identifier: %s'):format(
          identifier))
    else
      deferrals.done()
    end
  else
    deferrals.done(
      '[ESX] There was an error loading your character!\nError code: identifier-missing\n\nThe cause of this error is not known, your identifier could not be found. Please come back later or report this problem to the server administration team.')
  end
end)

function loadESXPlayer(identifier, playerId, isNew)
  local userData = {accounts = {}, inventory = {}, job = {}, loadout = {}, phone = '9999', playerName = GetPlayerName(playerId)}

  local result = MySQL.prepare.await(loadPlayer, {identifier})
  local job, grade, jobObject, gradeObject = result.job, tostring(result.job_grade)
  local foundAccounts, foundItems = {}, {}

  -- Accounts
  if result.accounts and result.accounts ~= '' then
    local accounts = json.decode(result.accounts)

    for account, money in pairs(accounts) do
      foundAccounts[account] = money
    end
  end

  for account, data in pairs(Config.Accounts) do
    if data.round == nil then
      data.round = true
    end
    local index = #userData.accounts + 1
    userData.accounts[index] = {
      name = account,
      money = foundAccounts[account] or Config.StartingAccountMoney[account] or 0,
      label = data.label,
      round = data.round,
      index = index
    }
  end

  -- Job
  if ESX.DoesJobExist(job, grade) then
    jobObject, gradeObject = ESX.Jobs[job], ESX.Jobs[job].grades[grade]
  else
    print(('[^3WARNING^7] Ignoring invalid job for ^5%s^7 [job: ^5%s^7, grade: ^5%s^7]'):format(identifier, job, grade))
    job, grade = 'unemployed', '0'
    jobObject, gradeObject = ESX.Jobs[job], ESX.Jobs[job].grades[grade]
  end

  userData.job.id = jobObject.id
  userData.job.name = jobObject.name
  userData.job.label = jobObject.label

  userData.job.grade = tonumber(grade)
  userData.job.grade_name = gradeObject.name
  userData.job.grade_label = gradeObject.label
  userData.job.grade_salary = gradeObject.salary

  userData.job.skin_male = {}
  userData.job.skin_female = {}

  if gradeObject.skin_male then
    userData.job.skin_male = json.decode(gradeObject.skin_male)
  end
  if gradeObject.skin_female then
    userData.job.skin_female = json.decode(gradeObject.skin_female)
  end

  -- Inventory
  if not Config.OxInventory then
    if result.inventory and result.inventory ~= '' then
      local inventory = json.decode(result.inventory)

      for name, count in pairs(inventory) do
        local item = ESX.Items[name]

        if item then
          foundItems[name] = count
        else
          print(('[^3WARNING^7] Ignoring invalid item ^5"%s"^7 for ^5"%s^7"'):format(name, identifier))
        end
      end
    end

    for name, item in pairs(ESX.Items) do
      local count = foundItems[name] or 0
      if count > 0 then
      end

      table.insert(userData.inventory,
        {name = name, count = count, label = item.label, limit = item.limit, usable = Core.UsableItemsCallbacks[name] ~= nil, rare = item.rare,
         canRemove = item.canRemove})
    end

    table.sort(userData.inventory, function(a, b)
      return a.label < b.label
    end)
  else
    if result.inventory and result.inventory ~= '' then
      userData.inventory = json.decode(result.inventory)
    else
      userData.inventory = {}
    end
  end

  -- Group
  if result.group then
    if result.group == "superadmin" then
      userData.group = "admin"
      print("[^3WARNING^7] ^5Superadmin^7 detected, setting group to ^5admin^7")
    else
      userData.group = result.group
    end
  else
    userData.group = 'user'
  end

  -- Loadout
  if not Config.OxInventory then
    if result.loadout and result.loadout ~= '' then
      local loadout = json.decode(result.loadout)

      for name, weapon in pairs(loadout) do
        local label = ESX.GetWeaponLabel(name)

        if label then
          if not weapon.components then
            weapon.components = {}
          end
          if not weapon.tintIndex then
            weapon.tintIndex = 0
          end

          table.insert(userData.loadout,
            {name = name, ammo = weapon.ammo, label = label, components = weapon.components, tintIndex = weapon.tintIndex})
        end
      end
    end
  end

  -- Position
  if result.position and result.position ~= '' then
    userData.coords = json.decode(result.position)
  else
    if Config['Position'] ~= nil then
      userData.coords = Config['Position'][math.random(1, #Config['Position'])]
    else
      print('[^3WARNING^7] Column ^5"position"^0 in ^5"users"^0 table is missing required default value. Using backup coords, fix your database.')
      userData.coords = {x = -269.4, y = -955.3, z = 31.2, heading = 205.8}
    end
  end

  -- Skin
  if result.skin and result.skin ~= '' then
    userData.skin = json.decode(result.skin)
  else
    if userData.sex == 'f' then
      userData.skin = {sex = 1}
    else
      userData.skin = {sex = 0}
    end
  end

  -- Identity
  if result.firstname and result.firstname ~= '' then
    userData.firstname = result.firstname
    userData.lastname = result.lastname
    userData.playerName = userData.firstname .. ' ' .. userData.lastname
    if result.dateofbirth then
      userData.dateofbirth = result.dateofbirth
    end
    if result.sex then
      userData.sex = result.sex
    end
    if result.height then
      userData.height = result.height
    end
  end

  -- phone
  if result.phone_number ~= '' then
    userData.phone = result.phone_number
  end

  local xPlayer = CreateExtendedPlayer(playerId, identifier, userData.group, userData.accounts, userData.inventory, userData.job,
    userData.loadout, userData.playerName, userData.coords, userData.phone)
  ESX.Players[playerId] = xPlayer
  Core.playersByIdentifier[identifier] = xPlayer

  if userData.firstname then
    xPlayer.set('firstName', userData.firstname)
    xPlayer.set('lastName', userData.lastname)
    if userData.dateofbirth then
      xPlayer.set('dateofbirth', userData.dateofbirth)
    end
    if userData.sex then
      xPlayer.set('sex', userData.sex)
    end
    if userData.height then
      xPlayer.set('height', userData.height)
    end
  end

  TriggerEvent('esx:playerLoaded', playerId, xPlayer, isNew)

  xPlayer.triggerEvent('esx:playerLoaded',
    {
      accounts = xPlayer.getAccounts(),
      phone = xPlayer.getPhone(),
      coords = xPlayer.getCoords(),
      identifier = xPlayer.getIdentifier(),
      inventory = xPlayer.getInventory(),
      job = xPlayer.getJob(),
      loadout = xPlayer.getLoadout(),
      money = xPlayer.getMoney(),
      sex = xPlayer.get("sex") or "m",
      dead = false
    }, isNew,
    userData.skin)

  xPlayer.updateCoords()

  print(('[^2INFO^0] Player ^5"%s"^0 has connected to the server. ID: ^5%s^7'):format(xPlayer.getName(), playerId))
end

AddEventHandler('chatMessage', function(playerId, author, message)
  local xPlayer = ESX.GetPlayerFromId(playerId)
  if message:sub(1, 1) == '/' and playerId > 0 then
    CancelEvent()
    local commandName = message:sub(1):gmatch("%w+")()
    xPlayer.showNotification(TranslateCap('commanderror_invalidcommand', commandName))
  end
end)

AddEventHandler('playerDropped', function(reason)
  local playerId = source
  local xPlayer = ESX.GetPlayerFromId(playerId)

  if xPlayer then
    TriggerEvent('esx:playerDropped', playerId, reason)

    Core.playersByIdentifier[xPlayer.identifier] = nil
    Core.SavePlayer(xPlayer, function()
      ESX.Players[playerId] = nil
    end)
  end
end)

AddEventHandler('esx:playerLogout', function(playerId, cb)
  local xPlayer = ESX.GetPlayerFromId(playerId)
  if xPlayer then
    TriggerEvent('esx:playerDropped', playerId)

    Core.playersByIdentifier[xPlayer.identifier] = nil
    Core.SavePlayer(xPlayer, function()
      ESX.Players[playerId] = nil
      if cb then
        cb()
      end
    end)
  end
  TriggerClientEvent("esx:onPlayerLogout", playerId)
end)

if not Config.OxInventory then
  RegisterNetEvent('esx:updateWeaponAmmo')
  AddEventHandler('esx:updateWeaponAmmo', function(weaponName, ammoCount)
    local xPlayer = ESX.GetPlayerFromId(source)

    if xPlayer then
      xPlayer.updateWeaponAmmo(weaponName, ammoCount)
    end
  end)

  RegisterNetEvent('esx:giveInventoryItem')
  AddEventHandler('esx:giveInventoryItem', function(target, type, itemName, itemCount)
    local playerId = source
    local sourceXPlayer = ESX.GetPlayerFromId(playerId)
    local targetXPlayer = ESX.GetPlayerFromId(target)
    local distance = #(GetEntityCoords(GetPlayerPed(playerId)) - GetEntityCoords(GetPlayerPed(target)))
    if not sourceXPlayer or not targetXPlayer or distance > Config.DistanceGive then
      print("[^3WARNING^7] Player Detected Cheating: ^5" .. GetPlayerName(playerId) .. "^7")
      return
    end

    if type == 'item_standard' then
      local sourceItem = sourceXPlayer.getInventoryItem(itemName)

      if itemCount > 0 and sourceItem.count >= itemCount then
        if targetItem.limit ~= -1 and (targetItem.count + itemCount) > targetItem.limit then
              TriggerClientEvent("pNotify:SendNotification", _source, {
                  text = 'คุณ <strong class="red-text">' .. targetXPlayer.name ..'</strong> ไม่สามารถรับไอเทมจากคุณได้เนื่องจากไอเทมเกินขีดจำกัด',
                  type = "error",
                  timeout = 3000,
                  layout = "bottomCenter",
                  queue = "global"
              })
          else
              sourceXPlayer.removeInventoryItem(itemName, itemCount)
              targetXPlayer.addInventoryItem(itemName, itemCount)
              
              TriggerClientEvent("pNotify:SendNotification", _source, {
                  text = 'ส่ง <strong class="amber-text">'.. ESX.Items[itemName].label ..'</strong> จำนวน ' .. itemCount,
                  type = "success",
                  timeout = 3000,
                  layout = "bottomCenter",
                  queue = "global"
              })
              TriggerClientEvent("pNotify:SendNotification", target, {
                  text = 'ได้รับ <strong class="amber-text">'.. ESX.Items[itemName].label ..'</strong> จำนวน ' .. itemCount,
                  type = "success",
                  timeout = 3000,
                  layout = "bottomCenter",
                  queue = "global"
              })

          local sendToDiscord = ''.. sourceXPlayer.name .. ' ส่ง ' .. ESX.GetItemLabel(itemName) .. ' ให้กับ ' .. targetXPlayer.name .. ' จำนวน ' .. ESX.Math.GroupDigits(itemCount) .. ''
              TriggerEvent('azael_discordlogs:sendToDiscord', 'GiveItem', sendToDiscord, _source, '^1')	
                              
              Citizen.Wait(100)
                              
              local sendToDiscord2 = ''.. targetXPlayer.name .. ' ได้รับ ' .. ESX.GetItemLabel(itemName) .. ' จาก ' .. sourceXPlayer.name .. ' จำนวน ' .. ESX.Math.GroupDigits(itemCount) .. ''
              TriggerEvent('azael_discordlogs:sendToDiscord', 'GiveItem', sendToDiscord2, target, '^2')
          end
      else
        TriggerClientEvent("pNotify:SendNotification", _source, {
              text = '<span class="red-text">ปริมาณที่ไม่ถูกต้อง</span>',
              type = "error",
              timeout = 3000,
              layout = "bottomCenter",
              queue = "global"
          })
      end
    elseif type == 'item_account' then
      if itemCount > 0 and sourceXPlayer.getAccount(itemName).money >= itemCount then
        sourceXPlayer.removeAccountMoney(itemName, itemCount, "Gave to " .. targetXPlayer.name)
        targetXPlayer.addAccountMoney(itemName, itemCount, "Received from " .. sourceXPlayer.name)

        local sendToDiscord = ''.. sourceXPlayer.name .. ' ส่ง ' .. Config.Accounts[itemName] .. ' ให้กับ ' .. targetXPlayer.name .. ' จำนวน $' .. ESX.Math.GroupDigits(itemCount) .. ''
			  TriggerEvent('azael_discordlogs:sendToDiscord', 'GiveMoney', sendToDiscord, sourceXPlayer.source, '^1')	
              
			  Citizen.Wait(100)
              
			  local sendToDiscord2 = ''.. targetXPlayer.name .. ' ได้รับ ' .. Config.Accounts[itemName] .. ' จาก ' .. sourceXPlayer.name .. ' จำนวน $' .. ESX.Math.GroupDigits(itemCount) .. ''
			  TriggerEvent('azael_discordlogs:sendToDiscord', 'GiveMoney', sendToDiscord2, targetXPlayer.source, '^2')

        TriggerClientEvent("pNotify:SendNotification", playerId, { --แจ้งเตือนเรา _source = owned
				    text = '<strong class="blue-text">ช่วยเหลือ</strong> ส่ง <strong class="amber-text">เงินสด</strong> จำนวน ' .. itemCount..'',
				    type = "information",
				    timeout = 5000,
				    layout = "centerRight",
				    queue = "global"
				})
				TriggerClientEvent("pNotify:SendNotification", target, { --แจ้งเตือนเป้าหมาย target = Other players
				    text = '<strong class="blue-text">ช่วยเหลือ</strong> ได้รับ <strong class="amber-text">เงินสด</strong> จำนวน ' .. itemCount..'',
				    type = "information",
				    timeout = 5000,
				    layout = "centerRight",
				    queue = "global"
				})
      else
        TriggerClientEvent("pNotify:SendNotification", source, {
          text = '<strong class="red-text">ล้มเหลว</strong> ปริมาณที่ไม่ถูกต้อง',
          type = "information",
          timeout = 5000,
          layout = "centerRight",
          queue = "global"
      })
      end
    elseif type == 'item_weapon' then
      if sourceXPlayer.hasWeapon(itemName) then
        local weaponLabel = ESX.GetWeaponLabel(itemName)
        if not targetXPlayer.hasWeapon(itemName) then
          local _, weapon = sourceXPlayer.getWeapon(itemName)
          local _, weaponObject = ESX.GetWeapon(itemName)
          itemCount = weapon.ammo
          local weaponComponents = ESX.Table.Clone(weapon.components)
          local weaponTint = weapon.tintIndex
          if weaponTint then
            targetXPlayer.setWeaponTint(itemName, weaponTint)
          end
          if weaponComponents then
            for k, v in pairs(weaponComponents) do
              targetXPlayer.addWeaponComponent(itemName, v)
            end
          end
          sourceXPlayer.removeWeapon(itemName)
          targetXPlayer.addWeapon(itemName, itemCount)

          if weaponObject.ammo and itemCount > 0 then
            local ammoLabel = weaponObject.ammo.label
            TriggerClientEvent("pNotify:SendNotification", source, {
                text = '<strong class="blue-text">ช่วยเหลือ</strong> ส่ง <strong class="amber-text">'.. weaponLabel ..'</strong> (กระสุน จำนวน ' .. itemCount ..')',
                type = "information",
                timeout = 5000,
                layout = "centerRight",
                queue = "global"
            })
            TriggerClientEvent("pNotify:SendNotification", target, {
                text = '<strong class="blue-text">ช่วยเหลือ</strong> ได้รับ <strong class="amber-text">'.. weaponLabel ..'</strong> (กระสุน จำนวน ' .. itemCount ..')',
                type = "information",
                timeout = 5000,
                layout = "centerRight",
                queue = "global"
            })
					else
						TriggerClientEvent("pNotify:SendNotification", source, {
                text = '<strong class="blue-text">ช่วยเหลือ</strong> ส่ง <strong class="amber-text">'.. weaponLabel ..'</strong>',
                type = "information",
                timeout = 5000,
                layout = "centerRight",
                queue = "global"
            })
            TriggerClientEvent("pNotify:SendNotification", target, {
                text = '<strong class="blue-text">ช่วยเหลือ</strong> ได้รับ <strong class="amber-text">'.. weaponLabel ..'</strong>',
                type = "information",
                timeout = 5000,
                layout = "centerRight",
                queue = "global"
            })
					end
        else
          TriggerClientEvent("pNotify:SendNotification", source, {
              text = '<strong class="red-text">ล้มเหลว</strong> ผู้เล่นมีอาวุธอยู่แล้ว',
              type = "information",
              timeout = 5000,
              layout = "centerRight",
              queue = "global"
          })
          TriggerClientEvent("pNotify:SendNotification", target, {
              text = '<strong class="red-text">ล้มเหลว</strong> คุณมีอาวุธอยู่แล้ว',
              type = "information",
              timeout = 5000,
              layout = "centerRight",
              queue = "global"
          })
        end
      end
    elseif type == 'item_ammo' then
      if sourceXPlayer.hasWeapon(itemName) then
        local weaponNum, weapon = sourceXPlayer.getWeapon(itemName)

        if targetXPlayer.hasWeapon(itemName) then
          local _, weaponObject = ESX.GetWeapon(itemName)

          if weaponObject.ammo then
            local ammoLabel = weaponObject.ammo.label

            if weapon.ammo >= itemCount then
              sourceXPlayer.removeWeaponAmmo(itemName, itemCount)
              targetXPlayer.addWeaponAmmo(itemName, itemCount)

              sourceXPlayer.showNotification(TranslateCap('gave_weapon_ammo', itemCount, ammoLabel, weapon.label, targetXPlayer.name))
              targetXPlayer.showNotification(TranslateCap('received_weapon_ammo', itemCount, ammoLabel, weapon.label, sourceXPlayer.name))
            end
          end
        else
          sourceXPlayer.showNotification(TranslateCap('gave_weapon_noweapon', targetXPlayer.name))
          targetXPlayer.showNotification(TranslateCap('received_weapon_noweapon', sourceXPlayer.name, weapon.label))
        end
      end
    end
  end)

  RegisterNetEvent('esx:removeInventoryItem')
  AddEventHandler('esx:removeInventoryItem', function(type, itemName, itemCount)
    local playerId = source
    local xPlayer = ESX.GetPlayerFromId(playerId)

    if type == 'item_standard' then
      if itemCount == nil or itemCount < 1 then
        TriggerClientEvent("pNotify:SendNotification", source, {
          text = '<strong class="red-text">ล้มเหลว</strong> ปริมาณที่ไม่ถูกต้อง',
          type = "information",
          timeout = 5000,
          layout = "centerRight",
          queue = "global"
        })
      else
        local xItem = xPlayer.getInventoryItem(itemName)

        if (itemCount > xItem.count or xItem.count < 1) then
          TriggerClientEvent("pNotify:SendNotification", source, {
              text = '<strong class="red-text">ล้มเหลว</strong> ปริมาณที่ไม่ถูกต้อง',
              type = "information",
              timeout = 5000,
              layout = "centerRight",
              queue = "global"
          })
        else
          xPlayer.removeInventoryItem(itemName, itemCount)
          TriggerClientEvent("pNotify:SendNotification", source, {
              text = '<strong class="green-text">ช่วยเหลือ</strong> คุณโยน <strong class="green-text">'..xItem.label..'</strong><strong class="yellow-text"> ['..itemCount..']</strong> ลงพื้น',
              type = "information",
              timeout = 5000,
              layout = "centerRight",
              queue = "global"
          })
          local sendToDiscord = ''.. xPlayer.name .. ' ทิ้ง '.. xItem.label ..' จำนวน ' .. ESX.Math.GroupDigits(itemCount) .. ''
				  TriggerEvent('azael_discordlogs:sendToDiscord', 'RemoveItem', sendToDiscord, xPlayer.source, '^1')
        end
      end
    elseif type == 'item_account' then
      if itemCount == nil or itemCount < 1 then
        TriggerClientEvent("pNotify:SendNotification", source, {
            text = '<strong class="red-text">ล้มเหลว</strong> ปริมาณที่ไม่ถูกต้อง',
            type = "information",
            timeout = 5000,
            layout = "centerRight",
            queue = "global"
        })
      else
        local account = xPlayer.getAccount(itemName)

        if (itemCount > account.money or account.money < 1) then
          TriggerClientEvent("pNotify:SendNotification", source, {
              text = '<strong class="red-text">ล้มเหลว</strong> ปริมาณที่ไม่ถูกต้อง',
              type = "information",
              timeout = 5000,
              layout = "centerRight",
              queue = "global"
          })
        else
          xPlayer.removeAccountMoney(itemName, itemCount, "Threw away")

          local sendToDiscord = ''.. xPlayer.name .. ' ทิ้ง ' .. Config.Accounts[itemName] .. ' จำนวน $' .. ESX.Math.GroupDigits(itemCount) .. ''
				  TriggerEvent('azael_discordlogs:sendToDiscord', 'RemoveMoney', sendToDiscord, xPlayer.source, '^1')
        end
      end
    elseif type == 'item_weapon' then
      itemName = string.upper(itemName)

      if xPlayer.hasWeapon(itemName) then
        local _, weapon = xPlayer.getWeapon(itemName)
        local _, weaponObject = ESX.GetWeapon(itemName)
        local components = ESX.Table.Clone(weapon.components)
        xPlayer.removeWeapon(itemName)

        if weaponObject.ammo and weapon.ammo > 0 then
          local ammoLabel = weaponObject.ammo.label
          xPlayer.showNotification(TranslateCap('threw_weapon_ammo', weapon.label, weapon.ammo, ammoLabel))
        else
          xPlayer.showNotification(TranslateCap('threw_weapon', weapon.label))
        end
      end
    end
  end)

  RegisterNetEvent('esx:useItem')
  AddEventHandler('esx:useItem', function(itemName)
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    local count = xPlayer.getInventoryItem(itemName).count

    if count > 0 then
      ESX.UseItem(source, itemName)
      
      local sendToDiscord = ''.. xPlayer.name .. ' ใช้ไอเทม ' .. ESX.GetItemLabel(itemName) .. ' จำนวน 1'
      TriggerEvent('azael_discordlogs:sendToDiscord', 'UseItem', sendToDiscord, xPlayer.source, '^3')
		else
			TriggerClientEvent("pNotify:SendNotification", source, {
				text = '<strong class="red-text">การกระทำเป็นไปไม่ได้</strong>',
				type = "error",
				timeout = 3000,
				layout = "bottomCenter",
				queue = "global"
			})
		end
  end)

end

ESX.RegisterServerCallback('esx:getPlayerData', function(source, cb)
  local xPlayer = ESX.GetPlayerFromId(source)

  cb({identifier = xPlayer.identifier, accounts = xPlayer.getAccounts(), inventory = xPlayer.getInventory(), job = xPlayer.getJob(),
      loadout = xPlayer.getLoadout(), money = xPlayer.getMoney(), position = xPlayer.getCoords(true)})
end)

ESX.RegisterServerCallback('esx:isUserAdmin', function(source, cb)
  cb(Core.IsPlayerAdmin(source))
end)

ESX.RegisterServerCallback('esx:getGameBuild', function(source, cb)
  cb(tonumber(GetConvar("sv_enforceGameBuild", 1604)))
end)

ESX.RegisterServerCallback('esx:getOtherPlayerData', function(source, cb, target)
  local xPlayer = ESX.GetPlayerFromId(target)

  cb({identifier = xPlayer.identifier, accounts = xPlayer.getAccounts(), inventory = xPlayer.getInventory(), job = xPlayer.getJob(),
      loadout = xPlayer.getLoadout(), money = xPlayer.getMoney(), position = xPlayer.getCoords(true)})
end)

ESX.RegisterServerCallback('esx:getPlayerNames', function(source, cb, players)
  players[source] = nil

  for playerId, v in pairs(players) do
    local xPlayer = ESX.GetPlayerFromId(playerId)

    if xPlayer then
      players[playerId] = xPlayer.getName()
    else
      players[playerId] = nil
    end
  end

  cb(players)
end)

AddEventHandler('txAdmin:events:scheduledRestart', function(eventData)
  if eventData.secondsRemaining == 60 then
    CreateThread(function()
      Wait(50000)
      Core.SavePlayers()
    end)
  end
end)

AddEventHandler('txAdmin:events:serverShuttingDown', function()
  Core.SavePlayers()
end)

