ESX = {}
ESX.Players = {}
ESX.Jobs = {}
ESX.Items = {}
Core = {}
Core.UsableItemsCallbacks = {}
Core.ServerCallbacks = {}
Core.ClientCallbacks = {}
Core.CurrentRequestId = 0
Core.RegisteredCommands = {}
Core.Pickups = {}
Core.PickupId = 0
Core.PlayerFunctionOverrides = {}

Core.playersByIdentifier = {}

AddEventHandler('esx:getSharedObject', function(cb)
  cb(ESX)
end)

exports('getSharedObject', function()
  return ESX
end)

local function StartDBSync()
  CreateThread(function()
    while true do
      Wait(10 * 60 * 1000)
      Core.SavePlayers()
    end
  end)
end

MySQL.ready(function()
  if not Config.OxInventory then
    local items = MySQL.query.await('SELECT * FROM items')
    for k, v in ipairs(items) do
      ESX.Items[v.name] = {label = v.label, limit = v.limit, rare = v.rare, canRemove = v.can_remove}
    end
  else
    TriggerEvent('__cfx_export_ox_inventory_Items', function(ref)
      if ref then
        ESX.Items = ref()
      end
    end)

    AddEventHandler('ox_inventory:itemList', function(items)
      ESX.Items = items
    end)

    while not next(ESX.Items) do
      Wait(0)
    end
  end

  ESX.RefreshJobs()

  print(('[^2INFO^7] ESX ^5Legacy %s^0 initialized!'):format(GetResourceMetadata(GetCurrentResourceName(), "version", 0)))
  print('^0[^6Extended Modifiedr By FewZ^0] ^2SCRIPTS => ^2ON :D^0')
  print('^2DISCORD ^0: ^6https://discord.gg/7Hn4WCf')
  print('^2Powered ^0: ^6FewZ-#3099')
  print(' ')
  print('^1════════════════════════════════════════════════════════^7')
  print('^1 H         H ^1 H H H H H H ^1 H         H ^1 NN         N')
  print('^1 H         H ^1 H           ^1 H         H ^1 N N        N')
  print('^1 H         H ^1 H           ^1 H         H ^1 N  N       N')
  print('^1 H         H ^1 H           ^1 H         H ^1 N   N      N')
  print('^1 H H H H H H ^1 H H H H H H ^1 H         H ^1 N    N     N')
  print('^1 H         H ^1 H           ^1 H         H ^1 N     N    N')
  print('^1 H         H ^1 H           ^1 H         H ^1 N      N   N')
  print('^1 H         H ^1 H           ^1 H         H ^1 N       N  N')
  print('^1 H         H ^1 H           ^1  H       H  ^1 N        N N')
  print('^1 H         H ^1 H           ^1    H H H    ^1 N         NN')
  print('^1════════════════════════════════════════════════════════^7')
  
  StartDBSync()
  if Config.EnablePaycheck then
		StartPayCheck()
	end
end)

RegisterServerEvent('esx:clientLog')
AddEventHandler('esx:clientLog', function(msg)
  if Config.EnableDebug then
    print(('[^2TRACE^7] %s^7'):format(msg))
  end
end)

RegisterServerEvent('esx:triggerServerCallback')
AddEventHandler('esx:triggerServerCallback', function(name, requestId,Invoke, ...)
  local source = source

  ESX.TriggerServerCallback(name, requestId, source,Invoke, function(...)
    TriggerClientEvent('esx:serverCallback', source, requestId,Invoke, ...)
  end, ...)
end)

RegisterNetEvent("esx:ReturnVehicleType", function(Type, Request)
  if Core.ClientCallbacks[Request] then
    Core.ClientCallbacks[Request](Type)
    Core.ClientCallbacks[Request] = nil
  end
end)
