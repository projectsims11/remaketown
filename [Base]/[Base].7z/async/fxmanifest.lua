fx_version 'cerulean'
game 'gta5'

author 'ESX-Framework'
description 'asynchronous Tasks'

shared_script 'async.lua'
