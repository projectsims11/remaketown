fx_version 'adamant'

game 'gta5'
author 'ESX-Framework'
description 'cron'

version '1.7.5'

server_script 'server/main.lua'
