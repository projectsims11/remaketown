Config = {}

Config.Framework = exports["es_extended"]:getSharedObject()

local sec = 1000
Config.Camping = {
    [1] = {
        ItemUse1 = 'lfish', -- ใช้อะไรในการปิ้ง
        ItemGet1 = 'water', -- ใช้แล้วได้ไอเท็มอะไร 

        UseCount1 = 3,  -- จำนวนที่ใช้ปิ้งย่าง
        time = 50,  --  เวลาในการปิ้งย่าง
        nothave1 = 'ปลาหมดแล้ว', --  ของหมดเตือนว่าอะไร

        camppoint = vector3(-419.3399963378906, 1146.6400146484375, 325.8599853515625),
        distance = 100.0,   -- กำหนดพิกัดปิ้งของไอเท็มชิ้นนี้

        prop = 'likemod_campfirefish_anim_props',   -- prop
        Heading = -20,  --  หันหัวทางไหน 

        ItemBonus = {   -- ไอเท็มโบนัส
            -- [1] = {itembonus = 'vip', itemBcount = 1, percent = 100},
            -- [2] = {itembonus = 'vipbox', itemBcount = 1, percent = 90}
        }
    },

}

Config.ShowBlip = true -- ไอคอนบนแมพ
Config.Blipname = '<font face="sarabun"> โซน ปิ้งย่าง </font>' -- ชื่อไอคอนบนแมพ

-- ===========================================
Config.HeadProps = '#' -- ถ้าไม่เอาพร้อมใส่ false
-- ===========================================