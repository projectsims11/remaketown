ESX = Config.Framework

for k, v in pairs(Config.Camping) do
    ESX.RegisterUsableItem(v.ItemUse1, function(source)
        local _source = source
        local xPlayer = ESX.GetPlayerFromId(_source)
        local xItem = xPlayer.getInventoryItem(v.ItemUse1)
        local xItem2 = xPlayer.getInventoryItem(v.ItemGet1)
        v.key = k
        if xItem.count < v.UseCount1 then
            TriggerClientEvent("pNotify:SendNotification", source, {
                text = 'ไอเทมไม่เพียงพอ',
                type = "error",
                timeout = 3000,
                layout = "bottomCenter",
                queue = "global"
            })
        else
            if xItem2.limit ~= -1 and xItem2.count >= xItem2.limit then
                TriggerClientEvent("pNotify:SendNotification", source, {
                    text = 'ไอเท็มของคุณเต็ม',
                    type = "error",
                    timeout = 3000,
                    layout = "bottomCenter",
                    queue = "global"
                })
            else
                TriggerClientEvent('START', source, v)
            end
        end
    end)
end

for k, v in pairs(Config.Camping) do
    RegisterServerEvent('Add' .. k)
    AddEventHandler('Add' .. k, function(kratom)
        local _source = source
        local xPlayer = ESX.GetPlayerFromId(_source)
        xPlayer.addInventoryItem(v.ItemGet1, 1)
        xPlayer.removeInventoryItem(v.ItemUse1, v.UseCount1)

        local content = '' .. xPlayer.name .. ' เสีย ' .. ESX.GetItemLabel(v.ItemUse1) .. ' จำนวน ' .. v.UseCount1 .. ' และ ได้รับ ' .. ESX.GetItemLabel(v.ItemGet1) .. ' จำนวน 1'
        TriggerEvent('azael_dc-serverlogs:insertData', 'JobCamping', content, xPlayer.source, 2)

        if v.ItemBonus ~= nil then
            for k, v in pairs(v.ItemBonus) do
                local ItemBonus = xPlayer.getInventoryItem(v.itembonus)
                if math.random(1, 100) <= v.percent then
                    if ItemBonus.limit ~= -1 and ItemBonus.count >
                        ItemBonus.limit then
                        TriggerClientEvent("pNotify:SendNotification", source, {
                            text = '<strong class="red-text">ไอเท็มโบนัสของคุณเต็ม</strong>',
                            type = "success",
                            timeout = 3000,
                            layout = "bottomCenter",
                            queue = "global"
                        })
                        xPlayer.setInventoryItem(v.itembonus,  ItemBonus.limit)

                        local content = '' .. xPlayer.name .. ' ได้รับ โบนัส ' .. ItemBonus.label .. ' จำนวน ' .. ItemBonus.limit - ItemBonus.count .. ''
                        TriggerEvent('azael_dc-serverlogs:insertData', 'JobCamping', content, xPlayer.source, 9)
                    else
                        xPlayer.addInventoryItem(v.itembonus, v.itemBcount)

                        local content = '' .. xPlayer.name .. ' ได้รับ โบนัส ' .. ItemBonus.label .. ' จำนวน ' .. v.itemBcount .. ''
                        TriggerEvent('azael_dc-serverlogs:insertData', 'JobCamping', content, xPlayer.source, 9)
                    end
                end
            end
        end
    end)
end