fx_version 'adamant' 
game 'gta5' 
 
client_scripts {
    "config.lua",
    "client/client.lua"
}

server_scripts {
    "config.lua",
    "server/server.lua"
}

files {
	"stream/*.ytd",
	"stream/*.ydr",
	"stream/*.ycd",
}

data_file 'DLC_ITYP_REQUEST' 'stream/text_afk.ytyp'
data_file 'DLC_ITYP_REQUEST' 'stream/likemod_campfirefish_anim_props.ytyp'