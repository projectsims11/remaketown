Locales['en'] = {

	['invoices'] = 'ใบแจ้งหนี้',
	['received_invoice'] = 'Your ~r~received~s~ an invoice',
	['paid_invoice'] = 'Your ~g~paid~s~ an invoice of ~r~$',
	['received_payment'] = 'Your ~g~received~s~ a payment of ~r~$',
	['player_not_logged'] = 'the player is not logged in',

}
