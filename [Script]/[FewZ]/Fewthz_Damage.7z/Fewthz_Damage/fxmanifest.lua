fx_version "adamant"
game "gta5"

description 'Fewthz'
modify 'Fewthz'

client_scripts {
	'Config.lua',
	'core/core_client.lua'
}