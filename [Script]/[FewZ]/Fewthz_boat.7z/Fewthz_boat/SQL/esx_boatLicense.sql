USE `es_extended`;

INSERT INTO `licenses` (`type`, `label`) VALUES
	('boat', 'Boat License')
;