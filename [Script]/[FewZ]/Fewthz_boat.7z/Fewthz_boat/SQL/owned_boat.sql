/*
 Navicat Premium Data Transfer

 Source Server         : qofegqofig
 Source Server Type    : MySQL
 Source Server Version : 100513
 Source Host           : localhost:3306
 Source Schema         : es_extended

 Target Server Type    : MySQL
 Target Server Version : 100513
 File Encoding         : 65001

 Date: 10/12/2021 01:03:15
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for owned_boat
-- ----------------------------
DROP TABLE IF EXISTS `owned_boat`;
CREATE TABLE `owned_boat`  (
  `owner` varchar(22) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `state` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Etat de la voiture',
  `plate` varchar(12) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `stored` tinyint(1) NOT NULL DEFAULT 1,
  `vehicle` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL,
  `type` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'car',
  `vehiclename` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT 'voiture',
  `health_engine` int(11) NOT NULL DEFAULT 1000,
  `health_body` int(11) NOT NULL DEFAULT 1000,
  `health_tank` int(11) NOT NULL DEFAULT 1000,
  PRIMARY KEY (`plate`) USING BTREE,
  INDEX `owner`(`owner`) USING BTREE,
  INDEX `stored`(`stored`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Compact;

SET FOREIGN_KEY_CHECKS = 1;
