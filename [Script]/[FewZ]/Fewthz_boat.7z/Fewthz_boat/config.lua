Config               = {}

Config.Locale        = 'en'

Config.LicenseEnable = false -- enable boat license? Requires esx_license
Config.LicensePrice  = 5000
Config.PriceGarage	 = 100		-- ค่าเบิกเรือ

Config.MarkerType    = 1
Config.DrawDistance  = 100.0

Config.Marker = {
	r = 100, g = 204, b = 100, -- blue-ish color
	x = 1.5, y = 1.5, z = 1.0  -- standard size circle
}

Config.StoreMarker = {
	r = 255, g = 0, b = 0,     -- red color
	x = 5.0, y = 5.0, z = 1.0  -- big circle for storing boat
}

Config.Zones = {

	Garages = {

		{ -- Elysian Fields, nearby the airport  อู่เรือ
			GaragePos  = vector3(45.95000076293945, -2792.590087890625, 4.71999979019165),
			SpawnPoint = vector4(37.25, -2804.7099609375, 1.02999997138977, 181.0),
			StorePos   = vector3(-7.34999990463256, -2744.840087890625, 0.17000000476837),
			StoreTP    = vector4(23.97999954223632, -2759.5, 6, 2.6)
		},

		{ -- Barbareno Rd เบิกเรือเกาะล่าสัตว์
			GaragePos  = vector3(4970.4599609375, -5170.89990234375, 1.23000001907348),
			SpawnPoint = vector4(4929.44, -5155.8, 0.43, 73.97),
			StorePos   = vector3(4959.77, -5166.22, 0.28),
			StoreTP    = vector4(4974.240234375, -5172.41015625, 2.41000008583068, 250.64)  
		},
	},

	BoatShops = {
		{ -- Shank St, nearby campaign boat garage
			Outside = vector3(9.9, -2758.4, 5.0),                        
			Inside = vector4(36.54, -2798.34, 0.89, 175.81)     
		}
	}

}

Config.Vehicles = {
	{model = 'seashark', label = 'Seashark', price = 45000},
	{model = 'suntrap', label = 'Suntrap', price = 60000},
	{model = 'toro', label = 'Toro', price = 100000},


}