Locales['en'] = {
  -- shop
  ['boat_shop'] = '<font face="sarabun">ร้านขายเรือ</font>',
  ['boat_shop_open'] = '~INPUT_CONTEXT~ <font face="sarabun">กดเพื่อเปิด~y~ร้านขายเรือ</font>',
  ['boat_shop_confirm'] = 'buy <span style="color: yellow;">%s</span> for <span style="color: orange;">$%s</span>?',
  ['boat_shop_bought'] = '<font face="sarabun">คุณได้ซื้อ</font> ~b~%s~s~ for ~g~$%s~s~',
  ['boat_shop_nomoney'] = '<font face="sarabun">~r~คุณไม่สามารถจ่ายเรือลำนี้!</font>',
  ['confirm_no'] = '<font face="sarabun">ไม่</font>',
  ['confirm_yes'] = '<font face="sarabun">ยืนยัน</font>',

  -- garage
  ['garage'] = '<font face="sarabun">การาจเบิกเรือ</font>',
  ['garage_open'] = '~INPUT_CONTEXT~ <font face="sarabun">กด~y~การาจเบิกเรือ</font>',
  ['garage_store'] = '~INPUT_CONTEXT~ <font face="sarabun">กดเพื่อเอา~y~เรือเข้าการาจ</font>',
  ['garage_taken'] = '<font face="sarabun">เรือถูกนำออกไปแล้ว!</font>',
  ['garage_stored'] = '<font face="sarabun">เรือถูกเก็บไว้อย่างปลอดภัยในโรงรถของคุณ!</font>',
  ['garage_noboats'] = '<font face="sarabun">คุณไม่มีเรือเก็บไว้! เปิดร้าน ~y~เพื่อซื้อ!</font>',
  ['garage_blocked'] = '<font face="sarabun">ไม่สามารถนำเรือออกได้เนื่องจากยานพาหนะอื่นกำลังขวางจุดเบิก!!</font>',
  ['garage_notowner'] = '<font face="sarabun">คุณไม่ได้เป็นเจ้าของเรือลำนี้!</font>',

  -- license
  ['license_menu'] = 'buy Boat License?',
  ['license_buy_no'] = 'no',
  ['license_buy_yes'] = 'buy Boat License <span style="color: green;">$%s</span>',
  ['license_bought'] = 'you have bought the ~y~Boat License~s~ for ~g~$%s~s~',
  ['license_nomoney'] = 'you cannot ~r~afford~s~ the ~y~Boat License~s~!',

  -- blips
  ['blip_garage'] = '<font face="sarabun">ท่าเรือ</font>',
  ['blip_shop'] = '<font face="sarabun">ร้านขายเรือ</font>',
}
