fx_version 'adamant'

game 'gta5'

description 'Notify'
version '1.0'

ui_page 'html/ui.html'

client_scripts {
	'client.lua',
}

files {
	'html/*.*'
}

export 'Alert'