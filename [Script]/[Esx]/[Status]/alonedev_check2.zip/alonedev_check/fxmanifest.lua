client_script '@xSentinel/Shared/xSentinel_Framework_CL.lua'
server_script '@xSentinel/Shared/xSentinel_Framework_SV.lua'
fx_version 'adamant' 
game 'gta5' 
 

shared_script {
  'config.lua'
}

client_scripts {
  "client.lua"
}

server_scripts {
  "server.lua"
}