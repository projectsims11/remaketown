## Routing Buckets

pma-voice natively supports routing buckets.