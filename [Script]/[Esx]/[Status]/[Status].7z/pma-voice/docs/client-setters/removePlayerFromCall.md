## removePlayerFromCall

## Description

Removes the player from the call

## NOTE: This is just syntactic sugar for `setCallChannel(0)`

```lua
-- Removes the player from the call channel
exports['pma-voice']:removePlayerFromCall()
```