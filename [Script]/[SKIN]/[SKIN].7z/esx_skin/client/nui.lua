local menu = {}

function check_ban(sex, name, value, type)
	if Config.Blacklist[sex] and Config.Blacklist[sex][name] and Config.Blacklist[sex][name][value] then
		local num
		if type == 'left' then
			num = value - 1
		else
			num = value + 1
		end
		local status = check_ban(sex, name, num, type)
		if status then
		    return status
		else
			return num
		end
	else
		return false
	end
end

function nui_menu(elements, submitcb, cancelcb, closecb) -- change
	
	menu.open = function()
		SendNUIMessage({
			type = 'setdate',
			data	= elements,
		})
		
		SendNUIMessage({
			status 	= true,
		})
		
		SetNuiFocus(true, true)
	end
	
	menu.submit = function(data)
		SendNUIMessage({
			status = false
		})
		
		SetNuiFocus(false, false)
		submitcb(data, menu)
	end
	
	menu.cancel = function(data)
		cancelcb(data, menu)
	end
	
	menu.close 	= function(data)
		SendNUIMessage({
			status = false
		})
		SetNuiFocus(false, false)
		DeleteSkinCam()
		closecb(data, menu)
	end
	
	menu.change = function(data)
		local skin, components, maxVals
		data.value = tonumber(data.value)
		TriggerEvent('skinchanger:getSkin', function(getSkin) skin = getSkin end)
		if skin[data.name] ~= data.value then
			local staus = check_ban(skin['sex'], data.name, data.value, data.type)
			if staus then
				data.value = staus
			end
			TriggerEvent('skinchanger:change', data.name, data.value)
			TriggerEvent('skinchanger:getData', function(comp, max)
				components, maxVals = comp, max
			end)
			for i=1, #elements, 1 do
				local newData = {}
				if elements[i].name ~= maxVals[elements[i].name] then
					newData.max = maxVals[elements[i].name]
				end
				if elements[i].textureof and data.name == elements[i].textureof then
					newData.value = 0
				elseif staus and elements[i].name == data.name then
					newData.value = staus
				end
				
				if newData.max and newData.value  then
					SendNUIMessage({
						type = 'update',
						name = elements[i].name,
						newData = newData,
					})
				end
			end
		end
	end
	
	menu.open()
end

RegisterNUICallback("submit", function(data, cb)
	menu.submit(data)
	cb("ok")
end)

RegisterNUICallback("change", function(data, cb)
	menu.change(data)
	cb("ok")
end)

RegisterNUICallback("cancel", function(data, cb)
	menu.cancel(data)
	cb("ok")
end)

RegisterNUICallback("close", function(data, cb)
	menu.close(data)
	cb("ok")
end)

-- ===============================================================

RegisterNUICallback("headermenu", function(data, cb)
	if data.type == 'Reset' then
		heading		= 90 + 0.0
		zoomOffset 	= Config.headermenu['Reset'].zoomOffset
        camOffset 	= Config.headermenu['Reset'].camOffset
	elseif data.type == 'redhat' then	-- หัว
		heading 	= 90 + 0.0
		zoomOffset 	= Config.headermenu['redhat'].zoomOffset
        camOffset 	= Config.headermenu['redhat'].camOffset
	elseif data.type == 'tshirt' then	-- ตัว
		heading 	= 90 + 0.0
		zoomOffset 	= Config.headermenu['tshirt'].zoomOffset
        camOffset 	= Config.headermenu['tshirt'].camOffset
	elseif data.type == 'trousers' then	-- ตัว
		heading 	= 90 + 0.0
		zoomOffset 	= Config.headermenu['trousers'].zoomOffset
        camOffset 	= Config.headermenu['trousers'].camOffset
	elseif data.type == 'hand' then		-- แขน
		heading 	= 90 + 0.0
		zoomOffset 	= Config.headermenu['foot'].zoomOffset
        camOffset 	= Config.headermenu['foot'].camOffset
	end
	cb("ok")
end)

RegisterNUICallback("camera", function(data, cb)	-- มุมมองกล้อง
	heading = data.value + 0.0
	cb("ok")
end)
