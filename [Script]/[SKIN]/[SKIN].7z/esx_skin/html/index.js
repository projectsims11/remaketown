const script_name = 'esx_skin';
function SendMessage(namespace, data){
	$.post('https://' + script_name +'/' + namespace, JSON.stringify(data));
}

const input = document.querySelector('input');
input.addEventListener('input', update_slider_cam);

function update_slider_cam(e) {
	const value = ((360 / 100) * e.target.value );
	SendMessage("camera", {
		type: 'slider_cam',
		value:e.target.value
	});
}

function update_value(name, value, type){
	SendMessage("change", {
		name: name,
		value:value,
		type:type
	});
}

function redhat(){
	SendMessage("headermenu", {
		type: 'redhat'
	});
}

function tshirt(){
	SendMessage("headermenu", {
		type: 'tshirt'
	});
}

function trousers(){
	SendMessage("headermenu", {
		type: 'trousers'
	});
}

function hand(){
	SendMessage("headermenu", {
		type: 'hand'
	});
}

function Reset(){
	const myElement = document.getElementById('slider');
	myElement.value = 90;
	SendMessage("headermenu", {
		type: 'Reset'
	});
}

function Buttonbuy(){
	SendMessage("submit", {});
}

function cancel(){
	SendMessage("cancel", {});
}


function input_Change(name){
	const myElement = document.getElementById(name);
	if (myElement.value) {
		if (Number(myElement.value) > myElement.max) {
			myElement.value = myElement.max;
		}
		else if(Number(myElement.value) < myElement.min){
			myElement.value = myElement.min;
		}
	}
	else{
		myElement.value = myElement.min;
	}
	update_value(name, myElement.value);
}

function click_left(name){
	const myElement = document.getElementById(name);
	var new_value = Number(myElement.value) - 1;
	if (new_value >= myElement.min && new_value <= myElement.max){
		myElement.value = new_value;
		update_value(name, myElement.value, 'left');
	}
}

function click_right(name){
	const myElement = document.getElementById(name);
	var new_value = Number(myElement.value) + 1;
	if (new_value >= myElement.min && new_value <= myElement.max){
		myElement.value = new_value;
		update_value(name, myElement.value);
	}
}

$(function () {
	closemenu = function(){
		SendMessage("close", {});
	}

	$(document).ready(function () {
		$("body").on("keyup", function (key) {
			$(".box-container").addClass("dorp");
			if (Config.closeKeys.includes(key.which)) { 
				SendMessage("cancel", {});

				closemenu();

			}
		});
	});

		
	function display(bool) {
		if (bool) {
			$(".ui").show();
			
			audio3.play();
			// $(".box-container").addClass("show");
		} else {
			$(".ui").hide();
				// $(".container-skinmenu").addClass("dorp");
			// $(".box-container").addClass("dorp");
			// $(".box-container").html("");

		}
	}
	display(false);
	window.addEventListener('message', function (event) {
		if (event.data.status == true) {
			const myElement = document.getElementById('slider');
			myElement.value = 90;
			display(true)
		} 
		else if (event.data.status == false) {
			display(false)
		}
		else if (event.data.type == 'update') {
			const myElement = document.getElementById(event.data.name);
			myElement.max = event.data.newData.max;
			if (!event.data.newData.value && event.data.newData.value != 0){
				return;
			}
			if (event.data.newData.value != myElement.value){
				myElement.value = event.data.newData.value;
				update_value(event.data.name, myElement.value);
			}
		}
		else if (event.data.type == 'setdate') {
			$(".container-skin").html("");
			$.each(event.data.data, function (index, data) {
				var apps = `
			
				<div class="item-list">
              		  <div class="name-skin">`+ data.label +`</div>
						<i class="fa-solid fa-angle-left"  onclick="click_left('`+ data.name +`'); audio2.play();"></i>
						<input type="number" class="input-filed" value="`+ data.value +`" min="`+ data.min +`" max="`+ data.max +`" id="`+ data.name +`" onChange="input_Change(this.id)" onkeyup="input_Change(this.id)">
					  <i class="fa-solid fa-angle-right" onclick="click_right('`+ data.name +`'); audio2.play();"></i>
           		</div>

				`;
				$(".container-skin").append(apps);
			});
		}
	})
})
