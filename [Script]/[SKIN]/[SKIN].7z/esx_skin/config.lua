Config = {}

Config.Locale = 'en'

Config.sql = 'oxmysql' -- oxmysql or mysql

Config.headermenu = {
	['Reset'] = {
		['zoomOffset'] = 1.55,
		['camOffset'] = 0.00,
	},
	['redhat'] = {	-- หัว
		['zoomOffset'] = 0.6,
		['camOffset'] = 0.65,
	},
	['tshirt'] = {	-- ตัว				
		['zoomOffset'] = 0.80,
		['camOffset'] = 0.15,
	},
	['trousers'] = {	-- ตัว				
		['zoomOffset'] = 1.00,
		['camOffset'] = -0.60,
	},
	['foot'] = {	-- เท้า
		['zoomOffset'] = 0.80,
		['camOffset'] = -0.80,
	},
}
-- 0 = ผู้ชาย  1 = ผู้หญิง

Config.Blacklist = {
	[0] = {	-- sex เพศ
		['torso_1'] = {
			-- [5] = true,
		},
		['pants_1'] = {
			-- [8] = true,
		},
	},

	[1] = {	-- sex เพศ
		['torso_1'] = {
			-- [6] = true,
		},
		['pants_1'] = {
			-- [7] = true,
		},
	},
	
}