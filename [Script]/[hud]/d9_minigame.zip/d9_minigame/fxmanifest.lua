

fx_version 'cerulean'
game 'gta5'

author 'D9_Dev'
description 'D9 Dev'

client_scripts {
	"client/client.lua"
}

server_scripts {}

ui_page{
    "html/dist/index.html"
}

files {
	'html/dist/**'
}
