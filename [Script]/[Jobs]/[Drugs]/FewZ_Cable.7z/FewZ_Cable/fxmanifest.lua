fx_version 'cerulean'
games { 'gta5' }

client_scripts {
	'Config.lua',
	'Core/Core.client.lua'
}

server_script {
	'Config.lua',
	'Core/Core.server.lua'
}