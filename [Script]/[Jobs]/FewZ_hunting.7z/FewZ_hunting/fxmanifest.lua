fx_version 'adamant'
game 'gta5'
version '1.0.0'
description 'Hunting Job'
author 'Jaturong Wandee'

client_scripts{
    'config.lua',
    'client/main.lua'
}


server_scripts{
    'config.lua',
    'server/main.lua'
}   

ui_page "html/index.html"

files {
    'html/index.html',
    'html/index.js',
    'html/index.css',
    'html/Img/close.png'
}
