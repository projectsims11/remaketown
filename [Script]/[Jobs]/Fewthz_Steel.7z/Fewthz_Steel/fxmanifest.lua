fx_version 'adamant'
game 'gta5'

description 'FewZ'

server_scripts {
  "Setting.lua",
  "SouceCode/server.lua"
}

client_scripts {
  "Setting.lua",
  "SouceCode/client.lua"
}