cfg = cfg or {}

cfg.Debug = false 

cfg.timeloop_function = false -- ใช้งาน ลูปเปิดปิด zone จากตัวสคริปนี้
cfg.timeloop_delay = 10 -- เช็คทุกๆ กี่วินาที