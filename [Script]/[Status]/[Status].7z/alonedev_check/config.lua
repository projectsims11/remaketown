cfg = cfg or {}

-- FOR DEBUG AND RESET VALUTE
cfg.Debug = true
cfg.ResetClient = true 
cfg.ResetServer = true 

-- ERROR CONTROLS
cfg.ErrorLimits = 50
cfg.AutoResetValue = false
