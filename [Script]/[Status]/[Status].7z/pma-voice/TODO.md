## TODO
- [ ] Ability to display radio members on the client.
- [ ] Use commands to define voiceModes in shared.lua and only leave debug logs in shared.lua.
- [ ] Convert the UI to React.
- [ ] Multiple radio channels.

## DONE
- [ x ] Implement a easy way to get the players current radio channel on the server.
- [ x ] Add the ability to override proximity with exports.
- [ x ] Rename everything that uses 'phone' to 'call' for consistency.
