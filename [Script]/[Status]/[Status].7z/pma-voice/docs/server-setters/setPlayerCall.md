## setPlayerCall

## Description

Sets the players call channel.

## Parameters

* **source**: The player to set the radio channel of
* **callChannel**: the radio channel to set the player to 

```lua
exports['pma-voice']:setPlayerCall(source, 1)
```